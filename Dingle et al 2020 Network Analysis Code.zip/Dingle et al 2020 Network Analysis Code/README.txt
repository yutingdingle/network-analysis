Developed by Mattia Bonzani, PhD and Yu-Ting Dingle, PhD 
Created March 2020


This code takes a numerical matrix of cross-correlation matrix in a MATLAB file and computes:
a. Modularity
b. Number of Modules 
c. Average Edge Weight
d. Average Clustering Coefficient
e. Average Path Length
f. Node Degree for individual nodes

Section I. Functional Connectivity Matrix Generation
[Note: skip this section if you already have the functional connectivitymatrix]
Here we use the open source software FluoroSNNAP (Patel et al. Automated quantification of neuronal networks and single-cell calcium dynamics using calcium imaging, J Neurosci Met, 2015)
FluoroSNNAP can be downloaded at https://www.seas.upenn.edu/~molneuro/software.html
Refer to FluoroSNNAP's user guide on image segmentation.

1. Run a functional connectivity analysis in FluoroSNNAP "Preference -> Analysis Module - > Estimate Functional Connectivity -> select the method (in our example, cross-correlation was used)
2. Open the the output file "processed analysis/FC/C"
3. Copy this C matrix to MATLAB workspace
4. Import this matrix as numerical matrix
5. Change the name of this matrix and save it under the same name in the same folder as this code.

Section II. Network Analysis
1. Open the "example.m" code
2. In line 42 and line 33, replace "sample_file" with the name of your matrix
3. Run
4. It will ask you "Do you want to binaryze the matrix?" If you answer y, enter a threshold between 0 and 1.
5. It will output:
"FinalTableNetworkData" that contains modularity, number of modules, average edge weight, average clustering coefficient, and average path length.
"Modules Composition" - first column is the module index, second column is the number of nodes in the module
"Node Degree" - each row is the node degree of a node from node 1 to N