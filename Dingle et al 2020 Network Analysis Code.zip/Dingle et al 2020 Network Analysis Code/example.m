% to compute some network parameters from the unidirected matrix. 

%Input:
% 1) A= unidirected matrix (weighted or binary).
% Do you want to binaryze the matrix?
% In the Command Window you must decleare if you want or not to binarize the input
% matrix (y or n). If yes, in the Command Window you must decleare also the
% threshold. 

%Outputs:
% 1) FinalTableNetworkData= A table summirizing the following parameters:
% N= number of nodes;
% Modularity= modularity value;
% numberModules= total number of modules;
% AverageEdgeWeight= the mean edge weight of the matrix;
% net_clus= average clustering coeficient;
% net_path= average path length;

%2)NodeDegree=A table summirizing:
% First column= the node index;
% Second column= the number of nodes that composes the modules.

% 3)ModulesComposition= A table summirizing:
% First column= the module index;
% Second column= average edge weight of the node.

%Required Codes:
% 1) avg_clus_matrix.m= a function to compute the average clusteirng coefficient for a input matrix M;
%written by Eric Bridgeford; Muldoon, S., Bridgeford, E. & Bassett, D. Small-World Propensity and Weighted Brain Networks. Sci Rep 6, 22057 (2016). https://doi.org/10.1038/srep22057

% 2) avg_path_matrix.m = a function to compute the average path length of a given matrix using the graphallshortestpaths built-in matlab function;
%written by Eric Bridgeford;Muldoon, S., Bridgeford, E. & Bassett, D. Small-World Propensity and Weighted Brain Networks. Sci Rep 6, 22057 (2016). https://doi.org/10.1038/srep22057  

% 3) clustering_coef_matrix.m = a modification of the clustering coefficient function provided in the brain connectivity toolbox; 
% code originally written by Mika Rubinov, UNSW, 2007-2010; modified/written by Eric Bridgeford; Muldoon, S., Bridgeford, E. & Bassett, D. Small-World Propensity and Weighted Brain Networks. Sci Rep 6, 22057 (2016). https://doi.org/10.1038/srep22057                                                                                                                                                    

%written by Mattia Bonzanni and Yu-Ting Dingle;
%Reference:

clear
clc
load sample_matrix_file                                                     % to load the Matrix (binary or weighted)
A=sample_matrix_file;
[FinalTableNetworkData NodeDegree ModulesComposition]=NetworkAnalysis(A);       